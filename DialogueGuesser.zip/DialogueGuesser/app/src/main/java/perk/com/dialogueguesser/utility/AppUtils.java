package perk.com.dialogueguesser.utility;

/**
 * Created by koroy on 12/19/2015.
 */
public class AppUtils {

    public static int SPLASH_TIME_OUT=3000;

    public static String LEVEL_INFO="level_info";

    public static final String PERK_API_KEY="566d72487d500f0649aa27106cb2ed5c2d7cad7b";
    public static final String PERK_EVENT_ID="dec7a9473a19850b67aff9c0394fba38be54d862";

}
